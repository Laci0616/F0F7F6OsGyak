#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include<sys/wait.h>

int main () {
pid_t cpid;
   if (fork() == 0) {
    char *args[]={"./child",NULL};
        execvp(args[0],args);
    exit(0);
    }
else  cpid = wait(NULL);
   return(0);
} 
