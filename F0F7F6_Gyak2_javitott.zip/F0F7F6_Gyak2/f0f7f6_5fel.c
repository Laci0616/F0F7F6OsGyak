#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include<sys/wait.h>

int main () {
pid_t pid;
   if (fork() == 0) {
    printf("exit");
    exit(0);
    }
int status;
     
    waitpid(pid, &status, 0);
 
    if ( WIFEXITED(status) )
    {
        int exit_status = WEXITSTATUS(status);       
        printf("Exit status of the child was %d\n",
                                     exit_status);
    }
if (fork() == 0) {
    printf("abort");
    void abort(void);
    }

     
    waitpid(pid, &status, 0);
 
    if ( WIFEXITED(status) )
    {
        int exit_status = WEXITSTATUS(status);       
        printf("Exit status of the child was %d\n",
                                     exit_status);
    }
	if (fork() == 0) {
    printf("error");
    int i=10;
    int j=i/0;
    }
    
     
    waitpid(pid, &status, 0);
 
    if ( WIFEXITED(status) )
    {
        int exit_status = WEXITSTATUS(status);       
        printf("Exit status of the child was %d\n",
                                     exit_status);
    }


   return(0);
} 	


